
<div id="header" class="shadow-sm bg-white position-sticky top-0 d-flex align-items-center px-3">
  <div class="row w-100">
      <div class="col-9 col-lg-5 position-relative ms-auto me-2 ps-0 pe-0">
        <div>
        </div>
      </div>
  </div>
</div>
