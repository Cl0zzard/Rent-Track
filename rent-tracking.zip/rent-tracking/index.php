<?php header("Location: dashboard"); ?>
